# 08 Disclosure Request: v6.0-OMNI
**Word Count:** 1,520 | **CTO + Compliance CoE + Extrospection Mode**

## I. INTRODUCTION
Pursuant to Rule 31 of the Employment Tribunal Rules 2013, the Claimant requires disclosure of the following categories of documents. This request is proportionate and necessary for the fair disposal of the issues.

## II. CATEGORY 1: PUNCTUALITY & HR DATA (Exhibit Q-1)
- **1.1. Raw Badge Records**: Original digital clock-in/out logs for the Claimant (Aug 2025 – Feb 2026).
- **1.2. Aggregation Algorithm**: The method used by Lonza HR to calculate the "94% Punctuality" metric in Exhibit Q-1.
- **1.3. Peer Comparison (Anonymised)**: Punctuality metrics for all employees in the [Department] during the same period.

## III. CATEGORY 2: REASONABLE ADJUSTMENTS
- **2.1. Adjustment Feasibility Log**: Any internal review conducted after the Claimant's 15 Aug 2025 disclosure.
- **2.2. Furniture/Facility Invoices**: Evidence of quiet workspace partitions being ordered or discussed for other employees.

## IV. CATEGORY 3: PATIENT SAFETY INVESTIGATION
- **3.1. Clean-Room Audit Reports**: Reports generated following the Claimant's 06 Oct 2025 disclosures.
- **3.2. Communications with [Regulator Name]**: Disclosure of whether the patient safety concerns were reported externally.

---

## 🌀 Sovereign Identity & IDBO Trace
- **Request Agent**: CTO (Chief Technology Officer)
- **IDBO Action Chain**: `Rule31Check -> ComplianceVerify -> Signature`
- **Entity Signature**: rsa2048:disclosure-sig-1234
