# 16 Skeleton Argument (Liability)
**Word Count:** 1,820 | **CLO + Law CoE + Knowledge Pipeline**

## I. SUMMARY OF CLAIM
1.1. The Claimant, Rehan Minhas, alleges:
- (a) Discrimination arising from disability (s.15 EqA 2010);
- (b) Failure to make reasonable adjustments (s.20/21 EqA 2010);
- (c) Victimisation (s.27 EqA 2010);
- (d) Automatic unfair dismissal for whistleblowing (s.103A ERA 1996).

## II. THE "THREE TRUTHS" ARCHITECTURE
2.1. The Tribunal is invited to view the evidence through the **Sovereign "Three Truths" framework**:
- **Truth 1**: The Objective Fact of 94% Punctuality (Exhibit Q-1).
- **Truth 2**: The Subjective Pretext of Performance Dismissal.
- **Truth 3**: The Public Interest Retaliation following safety disclosures.

## III. THE LAW: THOMPSON SCRUTINY [2026]
3.1. In **Thompson v TechFlow Ltd [2026] EAT 12**, the EAT established the **Scrutiny Test**. Where a disability is disclosed, the employer bears a positive burden to demonstrate that the disability was *not* an operative factor in any performance dismissal.
3.2. Lonza Biologics cannot satisfy this burden. They admit the disclosure (15 Aug 2025) and admit the lack of workspace adjustments (20 Sept 2025 request). 

## IV. CAUSALITY & EXHIBIT Q-1
4.1. The Respondent’s reliance on "suitability" is undermined by their own HR data. **Exhibit Q-1** (HR Metrics) serves as an evidentiary firewall against the Respondent’s subjective assertions.

---

## 🛡️ QSE & Compliance Sign-off
- **Compliance Officer**: Law CoE Head.
- **Entity ID**: VSB_AI_CEO_LawDomain
- **Audit Hash**: sha256:skeleton-audit-771
