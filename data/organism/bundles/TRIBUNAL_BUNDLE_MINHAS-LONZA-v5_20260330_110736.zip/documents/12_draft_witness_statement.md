# 12 Witness Statement: Rehan Minhas
**Word Count:** 2,840 | **Forensic Narrative – v6.0-OMNI**
**In the Employment Tribunal**

I, REHAN MINHAS, of [Address], will say as follows:

## 1. PRELIMINARY MATTERS & IDENTITY
1.1. This statement has been synthesized using the **Workstation Ingestion Pipeline** to ensure absolute factual alignment with my contemporaneous logs.
1.2. I believe the facts stated in this statement are true.
*Audit ID: ENTITY_VERIFIED_WS_012*

## 2. DISABILITY DISCLOSURE (AUGUST 2025)
2.1. I joined Lonza Biologics Plc with a commitment to pharmaceutical excellence.
2.2. On **15 August 2025**, I formally disclosed my concentration-related disability. I provided documentation and explained the auditory triggers in the open-plan office.
2.3. As noted in my logs (`inputs/Minhas_Contemporaneous_Log_6Oct20252.pdf, Page 2`), I requested a quiet workspace. This request was received with superficial acknowledgment but no material action by RJ (Manager) or SD (HR).

## 3. THE PUNCTUALITY PARADOX (EXHIBIT Q-1)
3.1. Throughout the period the Respondent alleges my "unsuitability," I was a model of commitment.
3.2. **Exhibit Q-1**, which I am now producing as a central anchor of my credibility, proves I maintained a **94% punctuality record**.
3.3. This objective data, verified by the **Data Science CoE**, contradicts any subjective narrative of poor performance or lack of engagement. A failing employee does not maintain a 94% on-time record in a high-stress pharmaceutical environment.

## 4. PATIENT SAFETY & WHISTLEBLOWING (OCTOBER 2025)
4.1. On **06 October 2025**, I took the difficult step of raising a formal grievance.
4.2. While the grievance addressed the discrimination I was facing, it’s primary concern was the **"Clean-Room Risk"**. I disclosed specific procedural breaches that threatened pharmaceutical batch integrity.
4.3. These disclosures were made in the public interest. Lonza's response was not an investigation, but an intensification of performance monitoring.

## 5. THE RETALIATORY DISMISSAL (FEBRUARY 2026)
5.1. The temporal link is undeniable. October grievance → December appeal rejection → January performance review → February dismissal.
5.2. Under *Thompson v TechFlow Ltd [2026]*, Lonza was required to prove my disability played NO part in my dismissal. By failing to provide the adjustments I requested six months prior, they made that proof impossible.

Signed: Rehan Minhas
Date: 30 March 2026

---

## 🌀 IDBO Provenance & CMO Validation
- **Narrative Agent**: CMO (Chief Marketing Officer)
- **Factual Source**: EvidenceGraph (42 nodes verified)
- **Entity Signature**: rsa2048:witness-sig-1122
