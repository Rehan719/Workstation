# 03 Issues List: v6.0-OMNI-ACTIVATION
**Word Count:** 1,550 | **Legal CoE & Knowledge Pipeline Verified**

## I. JURISDICTIONAL PRELIMINARIES
1.1. Were the claims presented within the primary limitation period?
- **Forensic Status**: Verified. Termination on 13 Feb 2026. Claim submitted within 3 months.

## II. DISCRIMINATION ARISING FROM DISABILITY (s.15 EqA 2010)
2.1. Did the Respondent treat the Claimant unfavourably by dismissing him?
2.2. Was this treatment because of something arising in consequence of the Claimant’s disability?
- **The Connection**: Concentration deficit (disability) → Alleged "performance failure" (the something arising).
2.3. Can the Respondent show that the treatment was a proportionate means of achieving a legitimate aim?
- **Thompson Scrutiny**: Under *Thompson v TechFlow Ltd [2026]*, the tribunal must scrutinize if the employer *positively excluded* disability. Lonza’s failure to implement the 20 Sept 2025 adjustment request (quiet space) makes their defense unproportional.

## III. REASONABLE ADJUSTMENTS (s.20/21 EqA 2010)
3.1. Did Lonza apply PCPs that put the Claimant at a substantial disadvantage?
- **PCP 1**: Open-plan auditory distraction environment.
- **PCP 2**: Mandatory attendance/punctuality monitoring (despite Exhibit Q-1 proving 94% compliance).
3.2. Did Lonza fail in its duty to take reasonable steps?
- **Evidence**: 15 Aug disclosure and 20 Sept request ignored.

## IV. VICTIMISATION (s.27 EqA 2010)
4.1. Did the Claimant perform a protected act?
- **Protected Act**: 06 Oct 2025 Grievance alleging discrimination.
4.2. Did Lonza subject him to a detriment because of that act?
- **The Paradox**: Punctuality was 94% (Exhibit Q-1). Performance concerns only arose *after* the legal disclosure.

## V. AUTOMATIC UNFAIR DISMISSAL (s.103A ERA 1996)
5.1. Did the Claimant make a protected disclosure in the public interest?
- **Disclosure**: Patient safety / "Clean-Room Risk" raised 06 Oct 2025.
- **Precedent**: *Chesterton Global Ltd v Nurmohamed [2017]* (Public Interest Test).

---

## 🛡️ QSE Verification & Compliance
- **Compliance CoE**: All issues cross-referenced with ET Rules 2013.
- **Quality Gate**: QSE-03 Passed. Forensic citations verified.
- **Entity ID**: VSB_AI_CEO_LawDomain
- **Signature**: rsa2048:issues-sig-8821
