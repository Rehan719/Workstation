Sovereign Digital Organism - Evidence Package
Case: MINHAS-LONZA-v5
Timestamp: 20260330_110736

To verify the integrity of this bundle, run:
sha256sum -c MANIFEST.sha256