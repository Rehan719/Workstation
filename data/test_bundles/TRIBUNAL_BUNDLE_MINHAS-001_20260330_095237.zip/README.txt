Sovereign Digital Organism - Evidence Package
Case: MINHAS-001
Timestamp: 20260330_095237

To verify the integrity of this bundle, run:
sha256sum -c MANIFEST.sha256